<?php
/**
* 2010-2021 PrestaLogik | Creative Agency
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to info@prestalogik.ch so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
* @Module		SumUp Payments Gateway
* @Description	SumUp Payments is the optimal solution for accepting card payments, in store or on the road.
* @Version		1.4.1
* @Author		PrestaLogik | Creative Web Agency <https://prestalogik.ch>
* @WebShop		ThirtyTools | Creative Developments <https://addons.prestalogik.ch>*
* @license		Valid for 1 website (or project) for each purchase 
*				of license International Registered Trademark & Property of PrestaLogik
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once(_PS_MODULE_DIR_ . DIRECTORY_SEPARATOR . 'sumuppaymentgateway' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'SumUpSplClassLoader.php');

if (version_compare(_PS_VERSION_, '1.7', '>')) {
    require_once(_PS_MODULE_DIR_ . DIRECTORY_SEPARATOR . 'sumuppaymentgateway' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'PaymentOptions.php');
}

class Sumuppaymentgateway extends PaymentModule
{
    public $isPs17 = false;
    private $app_id = '8dwmUCwOFE1kjJtV8mZQaOj0UYG0';
    private $app_secret = 'baea370c9c09638c2e16d660fce4987b67d7cf34d548931fa4d52b4dd144626b';
    private $grant_type = 'client_credentials';
    private $payment_message = 'PrestaShop Sumup payment module.';

    public function __construct()
    {
        $this->name = 'sumuppaymentgateway';
        $this->tab = 'administration';
        $this->version = '1.4.1';
        $this->author = 'PrestaLogik';
        $this->need_instance = 1;

        if (version_compare(_PS_VERSION_, '1.7', '>')) {
            $this->isPs17 = true;
        }

        $this->modulToken = Tools::encrypt($this->name . _COOKIE_KEY_);

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('SumUp Online Payments Gateway');
        $this->description = $this->l('SumUp Payments is the optimal solution for accepting card payments, in store or on the road.');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->initErrorMessages();
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {

        $languages = Language::getLanguages(false);
        $values = array();
        foreach ($languages as $lang) {
            $values['SUMUP_TEXT'][$lang['id_lang']] = 'Pay with SumUp';
        }

        $logoUrl = 'sumup_logo.png';

        Configuration::updateValue('SUMUP_PAYTO_MAIL', false);
        Configuration::updateValue('SUMUP_TEXT', $values['SUMUP_TEXT']);
        Configuration::updateValue('SUMUP_POPUP', false);
        Configuration::updateValue('SUMUP_LOGO', $logoUrl);

        include(dirname(__FILE__) . '/sql/install.php');

        $parentInstallRes = parent::install();
        $paymentHook = false;
        if (version_compare(_PS_VERSION_, '1.7', '>')) {
            $paymentHook = $this->registerHook('paymentOptions');
        } else {
            $paymentHook = $this->registerHook('payment');
        }
        return $parentInstallRes &&
            $this->registerHook('header') &&
            $this->registerHook('paymentReturn') &&
            $this->registerHook('backOfficeHeader') &&
            $paymentHook;
    }

    public function uninstall()
    {
        Configuration::deleteByName('SUMUP_PAYTO_MAIL');
        Configuration::deleteByName('SUMUP_TEXT');
        Configuration::deleteByName('SUMUP_POPUP');
        Configuration::deleteByName('SUMUP_LOGO');

        include(dirname(__FILE__) . '/sql/uninstall.php');

        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */

    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (Tools::isSubmit('submitSumuppaymentgatewayReset')) {
            Configuration::updateValue('SUMUP_PAYTO_MAIL', false);
            Configuration::updateValue('SUMUP_POPUP', false);
            Configuration::updateValue('SUMUP_LOGO', 'sumup_logo.png');
            Configuration::updateValue('SUMUP_TEXT', 'Pay with SumUp');

            $this->context->smarty->assign('success', $this->l('Successfully Reseted'));
        } else if (((bool)Tools::isSubmit('submitSumuppaymentgatewayModule')) == true) {
            $logoPath = _PS_MODULE_DIR_ . $this->name . '/views/img/payment_images/' . Configuration::get('SUMUP_LOGO');

            if (isset($_FILES['SUMUP_LOGO'])
                && isset($_FILES['SUMUP_LOGO'])
                && !empty($_FILES['SUMUP_LOGO']['tmp_name'])) {
                if ($error = ImageManager::validateUpload($_FILES['SUMUP_LOGO'], 4000000)) {
                    $this->errors[] = self::displayError($this->l($error));
                } else {
                    if (Configuration::get('SUMUP_LOGO') != 'sumup_logo.png') {
                        @unlink($logoPath);
                    }
                    $file_name = time() . '.png';
                    Configuration::updateValue('SUMUP_LOGO', $file_name);
                    move_uploaded_file($_FILES['SUMUP_LOGO']['tmp_name'], _PS_MODULE_DIR_ . $this->name . '/views/img/payment_images/' . $file_name);
                }
            }
            $this->context->smarty->assign('success', $this->l('Successfully Updated'));

            $this->postProcess();
        }


        $module_ok = Configuration::get('SUMUP_PAYTO_MAIL');

        $logoUrl = $this->getLogoUrl();
        Media::addJSDef(array('logoUrl' => $logoUrl));

        $this->context->smarty->assign('logoUrl', $logoUrl);
        $this->context->smarty->assign('module_dir', $this->_path);
        $this->context->smarty->assign('module_ok', $module_ok);

        $output = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');

        return $output . $this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitSumuppaymentgatewayModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'col' => 2,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-envelope"></i>',
                        'desc' => $this->l('Sumup Merchant Account Email'),
                        'name' => 'SUMUP_PAYTO_MAIL',
                        'label' => $this->l('Email'),
                    ),
                    array(
                        'type' => 'switch',
                        'col' => 2,
                        'label' => $this->l('Popup'),
                        'name' => 'SUMUP_POPUP',
                        'is_bool' => true,
                        'desc' => $this->l('Activate this option to view payment process in popup. If this option is disabled payment process will be continued in a new page'),
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'col' => 4,
                        'type' => 'text',
                        'lang' => true,
                        'prefix' => '<i class="icon icon-align-justify"></i>',
                        'desc' => $this->l('Text will appear in payment selection'),
                        'name' => 'SUMUP_TEXT',
                        'label' => $this->l('Text'),
                    ),
                    array(
                        'col' => 4,
                        'type' => 'file',
                        'desc' => $this->l('Upload new image if you want to change default Sumup logo. Recommended dimension: 65 x 65 '),
                        'name' => 'SUMUP_LOGO',
                        'label' => $this->l('Logo'),
                    ),
                ),
                'buttons' => array(
                    'newBlock' => array(
                        'title' => $this->l('Reset Settings'),
                        'class' => 'pull-left',
                        'type' => 'submit',
                        'name' => 'submitSumuppaymentgatewayReset',
                        'icon' => 'process-icon-reset'
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        $languages = Language::getLanguages(false);
        $fields = array();

        foreach ($languages as $lang) {
            $fields['SUMUP_TEXT'][$lang['id_lang']] = Tools::getValue('SUMUP_TEXT' . $lang['id_lang'], Configuration::get('SUMUP_TEXT', $lang['id_lang']));
        }

        $fields['SUMUP_PAYTO_MAIL'] = Configuration::get('SUMUP_PAYTO_MAIL');
        $fields['SUMUP_POPUP'] = Configuration::get('SUMUP_POPUP');

        return $fields;
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }

        $languages = Language::getLanguages(false);
        $values = array();
        foreach ($languages as $lang) {
            $values['SUMUP_TEXT'][$lang['id_lang']] = Tools::getValue('SUMUP_TEXT_' . $lang['id_lang']);
        }

        Configuration::updateValue('SUMUP_TEXT', $values['SUMUP_TEXT']);
    }

    /**
     * Add the CSS & JavaScript files you want to be loaded in the BO.
     */
    public function hookBackOfficeHeader()
    {
        if (Tools::getValue('module_name') == $this->name || Tools::getValue('configure') == $this->name) {
            $this->context->controller->addJquery();
            $this->context->controller->addJS($this->_path . 'views/js/back.js');
            $this->context->controller->addCSS($this->_path . 'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        $this->context->controller->addJquery();
        $this->context->controller->addJqueryPlugin('growl');
        $this->context->controller->addJS($this->_path . '/views/js/front.js');
        $this->context->controller->addJS($this->_path . '/views/js/iziModal.js');
        $this->context->controller->addCSS($this->_path . '/views/css/iziModal.css');
        $this->context->controller->addCSS($this->_path . '/views/css/front.css');
    }

    public function getLogoUrl()
    {
        return Tools::getHttpHost(true) . __PS_BASE_URI__ . 'modules/' . $this->name . '/views/img/payment_images/' . Configuration::get('SUMUP_LOGO');
    }

    public function hookPayment($params)
    {
        if (!$this->active) {
            return;
        }

        if (!Configuration::get('SUMUP_PAYTO_MAIL')) {
            return false;
        }

        $logoUrl = $this->getLogoUrl();

        $sumupPaymentOptions = $this->getSumupCheckoutId();

        $this->context->smarty->assign('secure_key', Context::getContext()->customer->secure_key);
        $this->context->smarty->assign('logoUrl', $logoUrl);
        $this->context->smarty->assign('popup', Configuration::get('SUMUP_POPUP'));
        $this->context->smarty->assign('text', Configuration::get('SUMUP_TEXT', $this->context->language->id));
        $this->context->smarty->assign('error_msg', $sumupPaymentOptions['error_msg']);
        $this->context->smarty->assign('paymentControllerLink', $sumupPaymentOptions['paymentUrl']);
        $this->context->smarty->assign('checkoutId', $sumupPaymentOptions['checkoutId']);
        $this->context->smarty->assign('locale', $this->getLocale());
        $this->context->smarty->assign('paymentAmount', $sumupPaymentOptions['paymentAmount']);
        $this->context->smarty->assign('paymentCurrency', $sumupPaymentOptions['paymentCurrency']);

        return $this->display(__FILE__, 'views/templates/hook/payment.tpl');
    }

    private function getSumupCheckoutId()
    {
        $link = new Link();
        $payToEmail = Configuration::get('SUMUP_PAYTO_MAIL'); //get from config the payto
        $id_card = Context::getContext()->cart->id;
        $cardObj = new Cart((int)$id_card);
        $totalPrice = $cardObj->getOrderTotal(true, Cart::BOTH);
        $currency = new Currency((int)$cardObj->id_currency);
        $paymentId = 'PrestaShop-SumUp-' . uniqid() . '-' . time() . '-id_card=' . $cardObj->id;
        $error_msg = "";
        $paymentUrl = "";
        $checkoutId = 0;

        $loader = new SumUpSplClassLoader("SumUp", _PS_MODULE_DIR_ . DIRECTORY_SEPARATOR . 'sumuppaymentgateway' . DIRECTORY_SEPARATOR . 'sumup_sdk' . DIRECTORY_SEPARATOR . 'src');
        $loader->register();

        try {
            $sumup = new \SumUp\SumUp(array(
                'app_id' => $this->app_id,
                'app_secret' => $this->app_secret,
                'grant_type' => $this->grant_type,
            ));

            $accessToken = $sumup->getAccessToken();

            $accessTokenValue = $accessToken->getValue();

            $sumup = new \SumUp\SumUp(array(
                'app_id' => $this->app_id,
                'app_secret' => $this->app_secret,
                'access_token' => $accessTokenValue,
            ));

            $checkoutService = $sumup->getCheckoutService();
            $checkoutResponse = $checkoutService->create(
                $totalPrice,
                $currency->iso_code,
                $paymentId,
                $payToEmail,
                $this->payment_message
            );

            $checkoutResponseBody = $checkoutResponse->getBody();
            if (!empty($checkoutResponseBody->id)) {
                $paymentUrl = $link->getModuleLink('sumuppaymentgateway', 'payment', array('checkoutId' => $checkoutResponseBody->id, 'amount' => $totalPrice, 'currency' => $currency->iso_code));
                $checkoutId = $checkoutResponseBody->id;
            } else {
                $error_msg = "General Error";
            }
        } catch (\SumUp\Exceptions\SumUpAuthenticationException $e) {
            $error_msg = $this->getErrorMessage('auth_error') . $e->getMessage();
            $traceInfoMessage = $this->getErrorMessageFromTrace($e->getTrace());
            if (!empty($traceInfoMessage)) {
                $error_msg .= ' ' . $traceInfoMessage;
            }
        } catch (\SumUp\Exceptions\SumUpResponseException $e) {
            $error_msg = $this->getErrorMessage('responce_err') . $e->getMessage();
            $traceInfoMessage = $this->getErrorMessageFromTrace($e->getTrace());
            if (!empty($traceInfoMessage)) {
                $error_msg .= ' ' . $traceInfoMessage;
            }
        } catch (\SumUp\Exceptions\SumUpSDKException $e) {
            $error_msg = $this->getErrorMessage('smp_sdk_err') . $e->getMessage();
            $traceInfoMessage = $this->getErrorMessageFromTrace($e->getTrace());
            if (!empty($traceInfoMessage)) {
                $error_msg .= ' ' . $traceInfoMessage;
            }
        }

        return array(
            'paymentUrl' => $paymentUrl,
            'error_msg' => $error_msg,
            'checkoutId' => $checkoutId,
            'paymentAmount' => $totalPrice,
            'paymentCurrency' => $currency->iso_code,
        );
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if (!Configuration::get('SUMUP_PAYTO_MAIL')) {
            return false;
        }


        $sumupPaymentOptions = $this->getSumupCheckoutId();
        $this->context->smarty->assign('popup', Configuration::get('SUMUP_POPUP'));
        $this->context->smarty->assign('error_msg', $sumupPaymentOptions['error_msg']);
        $this->context->smarty->assign('paymentControllerLink', $sumupPaymentOptions['paymentUrl']);
        $this->context->smarty->assign('checkoutId', $sumupPaymentOptions['checkoutId']);
        $this->context->smarty->assign('locale', $this->getLocale());
        $this->context->smarty->assign('paymentAmount', $sumupPaymentOptions['paymentAmount']);
        $this->context->smarty->assign('paymentCurrency', $sumupPaymentOptions['paymentCurrency']);

        $formHtml = $this->context->smarty->fetch('module:sumuppaymentgateway/views/templates/hook/payment1.7.tpl');

        return PaymentOptions::getPaymentOptions($formHtml, $this->getLogoUrl(), Configuration::get('SUMUP_TEXT', $this->context->language->id), $sumupPaymentOptions['error_msg']);
    }

    public function hookPaymentReturn($params)
    {
        if ($this->active == false) {
            return;
        }

        if ($this->isPs17) {
//            PS show confirmation view on 1.7 version
//            $order = $params['order'];
//            $total = @Tools::displayPrice($params['order']->total_paid_tax_incl, $params['order']->id_currency);
        } else {
            $total = Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false);
            $order = $params['objOrder'];
            if ($order->getCurrentOrderState()->id != Configuration::get('PS_OS_ERROR')) {
                $this->smarty->assign('status', 'ok');
            }


            $this->smarty->assign(array(
                'id_order' => $order->id,
                'reference' => $order->reference,
                'params' => $params,
                'total' => $total,
            ));

            return $this->display(__FILE__, 'views/templates/hook/confirmation.tpl');
        }
    }

    public function initErrorMessages()
    {
        $this->errorMessages = array(
            'card_not_loaded' => $this->l('Can not load cart data', $this->name),
            'auth_error' => $this->l('Authentication error: ', $this->name),
            'responce_err' => $this->l('Response error: ', $this->name),
            'smp_sdk_err' => $this->l('SumUp SDK error: ', $this->name),
            'payment_error' => $this->l('Can not process payment. Pleace check the card', $this->name),
            'order_create_err' => $this->l('Can not create order', $this->name),
            'secure_key_err' => $this->l('Invalid Secure key', $this->name),
        );
    }

    public function getErrorMessage($index)
    {
        return $this->errorMessages[$index];
    }

    private function getErrorMessageFromTrace($traceInfo)
    {
        $errorMessage = '';
        foreach ($traceInfo as $info) {
            if (!empty($info['args'])) {
                foreach ($info['args'] as $message) {
                    if (isset($message->message)) {
                        $errorMessage .= $message->message . ' ';
                    }
                }
            }
        }

        return $errorMessage;
    }

    public function getLocale()
    {
        if ($this->isPs17) {
            $locale = $this->context->language->locale;
        } else {
            $locale = $this->context->language->language_code;
            $locale = explode('-', $locale);
            $locale[1] = Tools::strtoupper($locale[1]);
            $locale = implode('-', $locale);
        }
        $suportedLocales = array(
            "bg-BG", "cs-CZ", "da-DK", "de-AT", "de-CH", "de-DE", "de-LU", "el-CY", "el-GR", "en-GB", "en-IE", "en-MT", "en-US", "es-CL", "es-ES", "et-EE", "fi-FI", "fr-BE", "fr-CH", "fr-FR", "fr-LU", "hu-HU", "it-CH", "it-IT", "lt-LT", "lv-LV", "nb-NO", "nl-BE", "nl-NL", "pt-BR", "pt-PT", "pl-PL", "sk-SK", "sl-SI", "sv-SE"
        );
        if (in_array($locale, $suportedLocales)) {
            return $locale;
        }

        return 'en-GB';
    }
}
