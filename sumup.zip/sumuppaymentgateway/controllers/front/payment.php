<?php
/**
* 2010-2021 PrestaLogik | Creative Agency
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to info@prestalogik.ch so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
* @Module		SumUp Payments Gateway
* @Description	SumUp Payments is the optimal solution for accepting card payments, in store or on the road.
* @Version		1.4.1
* @Author		PrestaLogik | Creative Web Agency <https://prestalogik.ch>
* @WebShop		ThirtyTools | Creative Developments <https://addons.prestalogik.ch>*
* @license		Valid for 1 website (or project) for each purchase 
*				of license International Registered Trademark & Property of PrestaLogik
*/

class SumuppaymentgatewayPaymentModuleFrontController extends ModuleFrontController
{
    private $app_id = '8dwmUCwOFE1kjJtV8mZQaOj0UYG0';
    private $app_secret = 'baea370c9c09638c2e16d660fce4987b67d7cf34d548931fa4d52b4dd144626b';
    private $grant_type = 'client_credentials';
    private $payment_message = 'PrestaShop Sumup payment module.';

    private $error_occured;

    public function postProcess()
    {
        if ($this->module->isPs17) {
            if (!$this->container) {
                $this->container = $this->buildContainer();
            }
        }

        if (Tools::isSubmit('submitValidateOrder')) {
            $jsonResponce = Tools::getValue('data');
            $responce = json_decode($jsonResponce);

            if ($responce->status == 'PAID') {
                return $this->confirmOrder($responce);
            }
            return $this->displayError('payment_error');
        }

        if (Tools::isSubmit('submitPaymentForm')) {
            if (Tools::getValue('secure_key') != Context::getContext()->customer->secure_key) {
                $msg = 'SumUp has an error confirmation order process: Invalid Secure key.';
                PrestaShopLogger::addLog($msg, 3, null, 'Cart', (int)Context::getContext()->cart->id, true);
                return $this->displayError('secure_key_err');
            }

            return $this->makeSumUpPayment();
        }

        $link = new Link();
        $checkoutId = Tools::getValue('checkoutId');
        $amount = Tools::getValue('amount');
        $currency = Tools::getValue('currency');
        $paymentUrl = $link->getModuleLink('sumuppaymentgateway', 'payment');
        $this->context->smarty->assign('secure_key', Context::getContext()->customer->secure_key);
        $this->context->smarty->assign('paymentControllerLink', $paymentUrl);
        $this->context->smarty->assign('checkoutId', $checkoutId);
        $this->context->smarty->assign('locale', $this->module->getLocale());
        $this->context->smarty->assign('paymentCurrency', $currency);
        $this->context->smarty->assign('paymentAmount', $amount);

        $templateName = 'sumup_payment_form.tpl';

        if ($this->module->isPs17) {
            $templateName = 'module:sumuppaymentgateway/views/templates/front/sumup_payment_form17.tpl';
        }

        return $this->setTemplate($templateName);
    }


    private function makeSumUpPayment()
    {
        $cardObj = new Cart((int)Context::getContext()->cart->id);
        $customer = new Customer((int)$cardObj->id_customer);

        if (!$cardObj->id) {
            $this->error_occured = true;
            return "Error Message";
        }

        $cardData = $this->getCardData();

        if (!$cardData) {
            return $this->displayError('card_not_loaded');
        }

        $this->payment_message .= ' Customer Mail: ' . $customer->email;

        $payToEmail = Configuration::get('SUMUP_PAYTO_MAIL'); //get from config the payto

        $totalPrice = $cardObj->getOrderTotal(true, Cart::BOTH);
        $currency = new Currency((int)$cardObj->id_currency);
        $shop_name = Configuration::get('PS_SHOP_NAME');
        $paymentId = $shop_name . '-PrestaShop-SumUp-' . uniqid() . '-' . time() . '-id_card=' . $cardObj->id;

        $loader = new SumUpSplClassLoader("SumUp", _PS_MODULE_DIR_ . DIRECTORY_SEPARATOR . 'sumuppaymentgateway' . DIRECTORY_SEPARATOR . 'sumup_sdk' . DIRECTORY_SEPARATOR . 'src');
        $loader->register();
        $error_msg = "";

        try {
            $sumup = new \SumUp\SumUp(array(
                'app_id' => $this->app_id,
                'app_secret' => $this->app_secret,
                'grant_type' => $this->grant_type,
            ));

            $accessToken = $sumup->getAccessToken();

            $accessTokenValue = $accessToken->getValue();

            $sumup = new \SumUp\SumUp(array(
                'app_id' => $this->app_id,
                'app_secret' => $this->app_secret,
                'access_token' => $accessTokenValue,
            ));

            $checkoutService = $sumup->getCheckoutService();
            $checkoutResponse = $checkoutService->create(
                $totalPrice,
                $currency->iso_code,
                $paymentId,
                $payToEmail,
                $this->payment_message
            );

            $checkoutResponseBody = $checkoutResponse->getBody();
            if (!empty($checkoutResponseBody->id)) {
                $paymentResponse = $checkoutService->payWithCard($checkoutResponseBody->id, $cardData);
                $paymentResponseBody = $paymentResponse->getBody();
                if ($paymentResponseBody->status == 'PAID') {
                    return $this->confirmOrder($paymentResponseBody);
                } else {
                    $error_msg = $this->module->getErrorMessage('payment_error');
                }
            }
        } catch (\SumUp\Exceptions\SumUpAuthenticationException $e) {
            $error_msg = $this->module->getErrorMessage('auth_error') . $e->getMessage();
            $traceInfoMessage = $this->getErrorMessageFromTrace($e->getTrace());
            if (!empty($traceInfoMessage)) {
                $error_msg .= ' ' . $traceInfoMessage;
            }
        } catch (\SumUp\Exceptions\SumUpResponseException $e) {
            $error_msg = $this->module->getErrorMessage('responce_err') . $e->getMessage();
            $traceInfoMessage = $this->getErrorMessageFromTrace($e->getTrace());
            if (!empty($traceInfoMessage)) {
                $error_msg .= ' ' . $traceInfoMessage;
            }
        } catch (\SumUp\Exceptions\SumUpSDKException $e) {
            $error_msg = $this->module->getErrorMessage('smp_sdk_err') . $e->getMessage();
            $traceInfoMessage = $this->getErrorMessageFromTrace($e->getTrace());
            if (!empty($traceInfoMessage)) {
                $error_msg .= ' ' . $traceInfoMessage;
            }
        }

        if ($error_msg != "") {
            return $this->displayError($error_msg, true);
        }
    }

    private function confirmOrder($responce)
    {
        $cart = new Cart((int)Context::getContext()->cart->id);
        $customer = new Customer((int)$cart->id_customer);
        $paidPrice = $responce->amount;

        $msg = 'SumUp confirm order';
        PrestaShopLogger::addLog($msg, 1, null, 'Cart', (int)$cart->id, true);


        $payment_status = (int)Configuration::get('PS_OS_PAYMENT');
        $message = ""; // You can add a comment directly into the order so the merchant will see it in the BO.
        $message .= 'Description: ' . $responce->description . ' - ';
        $message .= 'Transact Code: ' . $responce->transaction_code . ' - ';
        $message .= 'Transact Id: ' . $responce->transaction_id . ' - ';
        $message .= 'Checkout Id: ' . $responce->id . ' - ';
        $message .= 'Checkout Reference: ' . $responce->checkout_reference;
        /**
         * Converting cart into a valid order
         */

        $module_name = $this->module->displayName;
        $currency_id = (int)Context::getContext()->currency->id;
        $extra_vars = array();
        $extra_vars['transaction_id'] = $responce->transaction_id;

        /**
         * Get total paid price from API : $paidPrice
         */
        $this->module->validateOrder(Context::getContext()->cart->id, $payment_status, $paidPrice, $module_name, $message, $extra_vars, $currency_id, false, $customer->secure_key);

        /**
         * If the order has been validated we try to retrieve it
         */
        $order_id = (int)Order::getOrderByCartId((int)$cart->id);

        if ($order_id) {
            /**
             * The order has been placed so we redirect the customer on the confirmation page.
             */
            $msg = 'SumUp successfully confirm order';
            PrestaShopLogger::addLog($msg, 1, null, 'Cart', (int)Context::getContext()->cart->id, true);

            $module_id = $this->module->id;
            Tools::redirect('index.php?controller=order-confirmation&id_cart=' . Context::getContext()->cart->id . '&id_module=' . $module_id . '&id_order=' . $order_id . '&key=' . $customer->secure_key);
        } else {
            $msg = 'SumUp has an error on confirmation order process: Can not create order.';
            PrestaShopLogger::addLog($msg, 3, null, 'Cart', (int)Context::getContext()->cart->id, true);
            /**
             * An error occured and is shown on a new page.
             */
            return $this->displayError('order_create_err');
        }
    }

    private function getCardData()
    {
        $spm_card_number = Tools::getValue('spm_card_number');
        $spm_card_name = Tools::getValue('spm_card_name');
        $spm_card_expiry = Tools::getValue('spm_card_expiry');
        $smp_card_cvc = Tools::getValue('smp_card_cvc');
        if (empty($spm_card_number) ||
            empty($spm_card_name) ||
            empty($spm_card_expiry) ||
            empty($smp_card_cvc)) {
            return false;
        } else {
            list($spm_card_month, $spm_card_year) = explode('/', $spm_card_expiry);
            $spm_card_month = str_replace(' ', '', $spm_card_month);
            $spm_card_year = str_replace(' ', '', $spm_card_year);

            if (empty($spm_card_year) || empty($spm_card_month)) {
                return false;
            }
            $spm_card_number = str_replace(' ', '', $spm_card_number);
            return array(
                "name" => $spm_card_name,
                "number" => $spm_card_number,
                "expiry_month" => $spm_card_month,
                "expiry_year" => $spm_card_year,
                "cvv" => $smp_card_cvc
            );
        }
    }

    protected function displayError($message_index, $notIndex = false)
    {
        if (!$notIndex) {
            $message = $this->module->getErrorMessage($message_index);
        } else {
            $message = $message_index;
        }

        $this->context->smarty->assign('error', $message);
        if ($this->module->isPs17) {
            return $this->setTemplate('module:sumuppaymentgateway/views/templates/front/sumup_payment_error17.tpl');
        }
        return $this->setTemplate('sumup_payment_error.tpl');
    }

    private function getErrorMessageFromTrace($traceInfo)
    {
        $errorMessage = '';
        foreach ($traceInfo as $info) {
            if (!empty($info['args'])) {
                foreach ($info['args'] as $message) {
                    if (isset($message->message)) {
                        $errorMessage .= $message->message . ' ';
                    }
                }
            }
        }

        return $errorMessage;
    }
}
