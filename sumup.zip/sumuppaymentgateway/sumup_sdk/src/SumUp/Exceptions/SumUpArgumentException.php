<?php
/**
* 2010-2021 PrestaLogik | Creative Agency
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to info@prestalogik.ch so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
* @Module		SumUp Payments Gateway
* @Description	SumUp Payments is the optimal solution for accepting card payments, in store or on the road.
* @Version		1.4.1
* @Author		PrestaLogik | Creative Web Agency <https://prestalogik.ch>
* @WebShop		ThirtyTools | Creative Developments <https://addons.prestalogik.ch>*
* @license		Valid for 1 website (or project) for each purchase 
*				of license International Registered Trademark & Property of PrestaLogik
 */

namespace SumUp\Exceptions;

/**
 * Class SumUpArgumentException
 *
 * @package SumUp\Exceptions
 */
class SumUpArgumentException extends SumUpSDKException
{
}
